import static org.junit.Assert.assertEquals;

 
/**
 * The Class Test.
 */
public class Test {
 
  
  /**
   * test method for validating upper multiplication.
   */
  @org.junit.jupiter.api.Test
  public void testupperPowerMultiply() {
    assertEquals(1.0,DoublePower.upperPowerMultiply(1.0,1),0.0);
    assertEquals(81.0,DoublePower.upperPowerMultiply(3.0,4L),0.0);
  }
  
  /**
   * Test method to get nth root.
   */
  @org.junit.jupiter.api.Test
  public void testBelowPowerMultiply() {

    assertEquals(4,DoublePower.belowPowerMultiply(1024.0,5L),0.0);
    assertEquals(3,DoublePower.belowPowerMultiply(27.0,3L),0.0);
    assertEquals(3,DoublePower.belowPowerMultiply(27.0,3L),0.0);

  }
  


}
