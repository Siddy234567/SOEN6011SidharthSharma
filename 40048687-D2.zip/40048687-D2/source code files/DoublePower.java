import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

// TODO: Auto-generated Javadoc
/**
 * The Class DoublePower is used to predict the output of a^b^x.
 */
public class DoublePower {

  /** The numerator is used to multiply the B or X till the numerator times. */
  static long numerator;

  /** The denominator is used to get the nth root. */
  static long denominator;
  
  /** The al is used to store all the variables. */
  static ArrayList<Double> al = new ArrayList<Double>();

  /**
  * The main method which executes the whole program.
  *
  * @param args
  *            the arguments
  */
  public static void main(String[] args) {
    // TODO Auto-generated method stub
    Scanner sc = new Scanner(System.in);
    double theValueOfX = 0.0;
    double theValueOfB = 0.0;
    double theValueOfA = 0.0;
    boolean flag = false;

    al = getInputs(theValueOfX,theValueOfB,theValueOfA,sc,flag);
    
    theValueOfX = al.get(0);
    theValueOfB = al.get(1);
    theValueOfA = al.get(2);
    
    if (theValueOfX < 0) {
      theValueOfB = 1 / theValueOfB;
      DecimalFormat d1 = new DecimalFormat("#.#");
      theValueOfB = Double.parseDouble(d1.format(theValueOfB));
      theValueOfX = -theValueOfX;
    }

    if (theValueOfA == 0) {
      System.out.println("0");
      System.exit(0);
    }

    if (theValueOfA == 1 || theValueOfB == 0) {
      System.out.println("1");
      System.exit(0);
    }

    if (theValueOfX == 0) {
      System.out.println(theValueOfA);
      System.exit(0);
    }

    converting(theValueOfX);

    double firstOutput = 0.0;

    try {
      firstOutput = belowPowerMultiply(upperPowerMultiply(theValueOfB, numerator), denominator);
      
    } catch (Exception e) {
      System.out.println("Exceeded Limit");
      System.exit(0);
    }
    String check = Double.toString(firstOutput);

    for (int i = 0; i < check.length(); i++) {
      if (check.charAt(i) == 'E') {
        System.out.println("Googol number formation has led to memory full"
            + ". Select the lower range.");
        System.exit(0);
      }
    }

    if (firstOutput > Integer.MAX_VALUE || Double.isNaN(firstOutput)) {
      System.out.println("Googol number formation has led to memory full. Select the lower range.");
      System.exit(0);
    }

    DecimalFormat d2 = new DecimalFormat("#.#");
    double secondResult = Double.parseDouble(d2.format(firstOutput));
    double finalOutput = 0.0;

    converting(secondResult);
    try {

      finalOutput = belowPowerMultiply(upperPowerMultiply(theValueOfA, numerator), denominator);
    } catch (Exception e) {
      System.out.println("Exceeded Limit");
      System.exit(0);
    }
  
    if (finalOutput > Long.MAX_VALUE || Double.isNaN(finalOutput)) {
      System.out.println(
          "Googol number formation has led to memory full. Select the lower range. though the "
          + "expected value  of (a ^ b ^ x) is: " + finalOutput);
      System.exit(0);
    } else {
      System.out.println("Result of(a ^ b ^ x) is : " + finalOutput);
    }
  }
  
  /**
   * The main method which executes the whole program.
   *
   *  @param theValueOfX
   *            stores the value of X given by user.
   *  @param theValueOfB
   *            stores the value of B given by user.
   *  @param theValueOfA
   *            stores the value of A given by user.
   *  @param sc
   *            used to get the input from user.
   *  @param flag
   *            updates based on correct user input.
   *  @return the double
   */
  public static ArrayList<Double> getInputs(double theValueOfX,double theValueOfB,
      double theValueOfA,Scanner sc,boolean flag) {

    while (!flag) {
      try {
        System.out.println("Enter the value of X and only upto one decimal:-");
        theValueOfX = sc.nextDouble();
        al.add(theValueOfX);
        System.out.println("Enter the value of B  and only upto one decimal:-");
        theValueOfB = sc.nextDouble();

        while (theValueOfB < 0) {
          System.out.println("B cannot be Negative."
              + " Re-Enter the value of B and only upto one decimal:-");
          theValueOfB = sc.nextDouble();
        }
        al.add(theValueOfB);



        System.out.println("Enter the value of A and only upto one decimal:-");
        theValueOfA = sc.nextDouble();

        while (theValueOfA < 0) {
          System.out.println("A cannot be Negative. "
              + "Re-Enter the value of A  and only upto one decimal:-.");
          theValueOfA = sc.nextDouble();
        }
        al.add(theValueOfA);

        flag = true;
      } catch (InputMismatchException e) {
        sc.next();
        System.out.println("Enter only digits.");
      }
    }

    return al;
  }

  /**
  * Converting function is used to convert the fraction into numerator and
  * denominator.
  *
  * @param theValueOfX
  *            the the value of X
  */
  public static void converting(double theValueOfX) {

    String splitting = String.valueOf(theValueOfX);

    String[] splittingFurther = splitting.split("[.]");
    String num = splittingFurther[0] + splittingFurther[1];
    long localNumerator;

    long localDenominator = 1;

    if (splittingFurther[1].charAt(0) != '0') {
   
      localNumerator = Integer.parseInt(num);
      for (int i = 0; i < splittingFurther[1].length(); i++) {
        localDenominator = localDenominator * 10;
      }
    } else {
      localNumerator = Integer.parseInt(splittingFurther[0]);
    }
    numerator = localNumerator;
    denominator = localDenominator;
  }

  /**
  * Upper power multiply function multiplies the number till the numerator times.
  *
  * @param theValueOfB
  *            is multiplied till the numerator times.
  * @param numerator
  *            the numerator
  * @return the double
  */
  public static double upperPowerMultiply(double theValueOfB, long numerator) {

    double theFirstPower = 1;

    for (int i = 0; i < numerator; i++) {
      theFirstPower = theFirstPower * theValueOfB;
    }

  
    BigDecimal.valueOf(theFirstPower).toPlainString();
    return theFirstPower;
  }

  /**
  * Below power multiply function depicts the nth root of a given number.
  *
  * @param theFirstPower
  *            is the number for which the nth root is to be obtained.
  * @param denominator
  *            which acts as a nth root.
  * @return the double
  */
  public static double belowPowerMultiply(double theFirstPower, long denominator) {

    double guessNumber = Math.random() % 10; // Random Number guess
    double accuracyFactor = 0.001; // more accuracy achiever
    double maxValueOfInt = 2147483647; //
    double currentValueOfX = 0.0;

    while (maxValueOfInt > accuracyFactor) {
      currentValueOfX = ((denominator - 1.0) * guessNumber 
        +
        (double) theFirstPower / upperPowerMultiply(guessNumber, denominator - 1))
        / (double) denominator;

      maxValueOfInt = Math.abs(currentValueOfX - guessNumber);
      guessNumber = currentValueOfX;
    }

    DecimalFormat d2 = new DecimalFormat("#.##");
    currentValueOfX = Double.parseDouble(d2.format(currentValueOfX));
    BigDecimal.valueOf(currentValueOfX).toPlainString();
    return currentValueOfX;
  }

}